package sample;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/*name.substring(i, i + 1).equals("0") || name.substring(i, i + 1).equals("1") ||
                        name.substring(i, i + 1).equals("2") || name.substring(i, i + 1).equals("3") ||
                        name.substring(i, i + 1).equals("4") || name.substring(i, i + 1).equals("5") ||
                        name.substring(i, i + 1).equals("6") || name.substring(i, i + 1).equals("7") ||
                        name.substring(i, i + 1).equals("8") || name.substring(i, i + 1).equals("9") || name.substring(i, i + 1).equals("."))*/

public class Controller {
    public static float A[] = new float[20];
    String name = new String();
    String input = new String();// Для параметров функции
    float zero, one, two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, thirteen;
    float fourteen, fifteen, sixteen, seventeen, eighteen, nineteen;
    int initium, finis; // Начало и конец вхождения
    double vihod;
    String number = new String(); // Для имени функции
    Econlib t = new Econlib();

    @FXML
    private ResourceBundle resources;


    @FXML
    private URL location;

    @FXML
    private TextArea Inlet;

    @FXML
    private TextArea Conclusion;

    @FXML
    private LineChart<?, ?> LineChart;

    @FXML
    private Button Equally;


    @FXML
    private TextArea Conclusion1;

    @FXML
    private Button Epp;

    @FXML
    void ClickGrafics(MouseEvent event) {
        // здесь проблема
        XYChart.Series series = new XYChart.Series();
        series.getData().add(new XYChart.Data(1, 23));
        //
    }
    @FXML
    void signUpBtClick(MouseEvent event) {
        name = Inlet.getText().trim();

        String name_protect = new String();
        name_protect = name;
        name_protect = name_protect.replaceAll("\\s+", "");
        if (name_protect.isEmpty()) {
            Inlet.setStyle("-fx-border-color:red");
        } else {

            name = name.replaceAll("\n", " ");

            for (int i = 0; i < name.length(); i++) {
                if (name.substring(i, i + 1).equals(" ")) {
                    initium = i + 1;
                    break;
                }
            }

            for (int i = name.length() - 1; i > 0; --i) {
                if (name.substring(i, i + 1).equals("0") || name.substring(i, i + 1).equals("1") ||
                        name.substring(i, i + 1).equals("2") || name.substring(i, i + 1).equals("3") ||
                        name.substring(i, i + 1).equals("4") || name.substring(i, i + 1).equals("5") ||
                        name.substring(i, i + 1).equals("6") || name.substring(i, i + 1).equals("7") ||
                        name.substring(i, i + 1).equals("8") || name.substring(i, i + 1).equals("9") || name.substring(i, i + 1).equals(".")) {
                    finis = i + 1;
                    break;
                }
            }

            input = name.substring(initium, finis); // Получилась строка со значеними для функции
            name = name.replace(input, "");
            name = name.replaceAll("\\s+", ""); // Получилась строка с именем функции

            input = input.trim();
            input = input + " ";
            String yt = new String();
            int j = 0;
            int proch = 0;
            for (int p = 0; p < input.length(); p++) {
                if (input.substring(p, p + 1).equals(" ")) {
                    input.substring(proch, p).replaceAll("\\s+", "");
                    A[j] = Float.parseFloat(input.substring(proch, p));
                    j++;
                    proch = p;
                }
            }


            vihod = t.Answer(name);
            Inlet.clear();
            Conclusion.appendText(name);
            number = Double.toString(vihod);
            Conclusion.appendText("\n" + number + "\n");
        }
    }

    @FXML
    void initialize() {
    }

}









 /*   @FXML
    private Button myButton;

    public void createLine(ActionEvent event) {

    }*/